# OpenGL-POC

OpenGL POC

#### How to run

```bash
# Change directory to the project root

# Create build dir
mkdir build

# Change dir to build
cd build

# Generate make files
cmake ../

# Compile and build the executable
make

# Run the app
./app

```

